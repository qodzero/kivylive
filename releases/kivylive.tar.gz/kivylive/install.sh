#!/bin/bash

echo '[!] Need to Create Base Directory In /opt Folder: '
sudo mkdir -p /opt/kivylive
sudo mv -v kivylive /opt/kivylive/
sudo mv -v icon.png /opt/kivylive/
sudo mv -v kivylive.desktop ~/.local/share/applications/
echo "[!] All Set, Open Your Dash And Just Search For Kivylive"
